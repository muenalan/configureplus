CONFIGUREPLUS_SESSION=$(cat .configureplus/global/CONFIGUREPLUS_SESSION)

source .configureplus/session/$CONFIGUREPLUS_SESSION.bash
