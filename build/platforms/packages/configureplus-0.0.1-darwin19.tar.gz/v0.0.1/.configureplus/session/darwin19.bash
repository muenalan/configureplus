
# Generated with configureplus (CONFIGUREPLUS_VERSION=0.1, CONFIGUREPLUS_PWD=/Users/muenalan/git-workdirs/github.com/muenalan/bash/configureplus/platforms/darwin19)

export CONFIGUREPLUS_DIR_CONFIG='/Users/muenalan/.config/configureplus'
export CONFIGUREPLUS_DIR_OUT='.configureplus'
export CONFIGUREPLUS_DIR_OUT_SESSIONS='.configureplus/session'
export CONFIGUREPLUS_PWD='/Users/muenalan/git-workdirs/github.com/muenalan/bash/configureplus/platforms/darwin19'
export CONFIGUREPLUS_SESSION='darwin19'
export CONFIGUREPLUS_VERSION='0.1'
export CONFIGURE_BASH_PROFILE_FILE='/Users/muenalan/.bash_profile'
export CONFIGURE_DIR_OUTPUT='platforms'
export CONFIGURE_DIR_TEMPLATE='template'
export CONFIGURE_FLAG_TOOL_BTEST=''
export CONFIGURE_GIT_TAG='v0.0.1'
export CONFIGURE_MKTEMP='/var/folders/px/ctnmlq5n5gbf154mj25wzdxh0000gn/T/tmp.i9iHTu6g'
export CONFIGURE_OSTYPE='darwin19'
export CONFIGURE_PKGNAME='configureplus'
export CONFIGURE_TIMESTAMP='Sat May 20 11:52:43 CEST 2023'
export CONFIGURE_VERSION='0.0.1'
