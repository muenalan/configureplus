
# Generated with configureplus (CONFIGUREPLUS_VERSION=0.1, CONFIGUREPLUS_PWD=/Users/muenalan/git-workdirs/github.com/muenalan/bash/configureplus/platforms/darwin19)

export CONFIGUREPLUS_SESSION='darwin19'
export CONFIGURE_DIR_OUTPUT='platforms'
export CONFIGURE_DIR_TEMPLATE='template'
export CONFIGURE_PKGNAME='configureplus'
export CONFIGURE_VERSION='0.1'
